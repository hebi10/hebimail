// Menu.tsx
import React from 'react';
import styles from './Menu.module.css';

interface MenuProps {
  onClose: () => void;
}

const Menu: React.FC<MenuProps> = ({ onClose }) => {
  return (
    <div className={styles["menu-container"]}>
      <button onClick={onClose} className={styles["close-button"]}>
        닫기
      </button>
      {/* 여기 메뉴 내용을 추가하세요 */}
    </div>
  );
};

export default Menu;
