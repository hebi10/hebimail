import React from 'react';
import styles from './CartPage.module.css';

const CartPage: React.FC = () => {
    return (
        <div className={styles.cartContainer}>
            <h1>Your Cart</h1>
            <div className={styles.cartItems}>
                {/* Cart items list */}
                <div className={styles.cartItem}>
                    <p>Product Name</p>
                    <p>$99.99</p>
                    <button className={styles.removeItemBtn}>Remove</button>
                </div>
                {/* ... */}
            </div>
            <div className={styles.total}>
                <p>Total: $199.98</p>
                <button className={styles.checkoutBtn}>Proceed to Checkout</button>
            </div>
        </div>
    );
};

export default CartPage;
