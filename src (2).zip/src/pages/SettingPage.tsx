import React from 'react';

const SettingPage: React.FC = () => {
  return (
    <div>
      <h1>Setting Page</h1>
    </div>
  );
};

export default SettingPage;
