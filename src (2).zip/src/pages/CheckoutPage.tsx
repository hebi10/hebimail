import React from 'react';

const CheckoutPage: React.FC = () => {
  return <div>Checkout Page</div>;
};

export default CheckoutPage;
