import React from 'react';

const RegisterPage: React.FC = () => {
  return (
    <div>
      <h1>Register Page</h1>
    </div>
  );
};

export default RegisterPage;
