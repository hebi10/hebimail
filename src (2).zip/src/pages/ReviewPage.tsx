import React from 'react';

const ReviewPage: React.FC = () => {
  return <div>Review Page</div>;
};

export default ReviewPage;
