import React from 'react';

const UserPage: React.FC = () => {
  return (
    <div>
      <h1>User Page</h1>
    </div>
  );
};

export default UserPage;
