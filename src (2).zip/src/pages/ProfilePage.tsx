import React from 'react';

const ProfilePage: React.FC = () => {
  return <div>Profile Page</div>;
};

export default ProfilePage;
