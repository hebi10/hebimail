import React from 'react';

const SignUpPage: React.FC = () => {
  return <div>Sign Up Page</div>;
};

export default SignUpPage;
