import React from 'react';
import styles from './ProductPage.module.css';

const ProductPage: React.FC = () => {
    return (
        <div className={styles.productContainer}>
            <div className={styles.productImage}>
                <img src="/path-to-product-image.jpg" alt="Product Name" />
            </div>
            <div className={styles.productDetails}>
                <h1>Product Name</h1>
                <p className={styles.price}>$99.99</p>
                <p className={styles.description}>
                    This is the description of the product. It is very detailed and informative.
                </p>
                <button className={styles.addToCartBtn}>Add to Cart</button>
            </div>
        </div>
    );
};

export default ProductPage;
