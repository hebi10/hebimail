import React from 'react';
import styles from './BoardPage.module.css';

const BoardPage: React.FC = () => {
    return (
        <div className={styles.boardContainer}>
            <h1>Discussion Board</h1>
            <div className={styles.postForm}>
                <textarea placeholder="Write your post here..." className={styles.textArea}></textarea>
                <button className={styles.postBtn}>Post</button>
            </div>
            <div className={styles.posts}>
                {/* 게시글 리스트 */}
                <div className={styles.post}>
                    <h3>Post Title</h3>
                    <p>This is the content of the post.</p>
                </div>
                {/* ... */}
            </div>
        </div>
    );
};

export default BoardPage;
