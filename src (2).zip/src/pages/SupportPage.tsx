import React from 'react';

const SupportPage: React.FC = () => {
  return <div>Support Page</div>;
};

export default SupportPage;
