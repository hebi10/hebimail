import React from 'react';
import styles from './CategoryPage.module.css';

const CategoryPage: React.FC = () => {
    return (
        <div className={styles.categoryContainer}>
            <h1>Product Categories</h1>
            <div className={styles.categoryList}>
                {/* 카테고리 리스트 */}
                <div className={styles.categoryCard}>Category 1</div>
                <div className={styles.categoryCard}>Category 2</div>
                <div className={styles.categoryCard}>Category 3</div>
                {/* ... */}
            </div>
        </div>
    );
};

export default CategoryPage;
