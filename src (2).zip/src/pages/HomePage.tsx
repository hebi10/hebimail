import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import SwiperCore, { Navigation } from 'swiper';

SwiperCore.use([Navigation]);

const HomePage: React.FC = () => {
  return (
    <>
      <div>
        <Swiper
          spaceBetween={30}
          slidesPerView={1}
          navigation
        >
          <SwiperSlide>Slide 1</SwiperSlide>
          <SwiperSlide>Slide 2</SwiperSlide>
          <SwiperSlide>Slide 3</SwiperSlide>
        </Swiper>
      </div>
      <div className={styles.homeContainer}>
        <div className={styles.banner}>
          <h1>Welcome to Hebi Mall</h1>
          <p>Your one-stop shop for all things amazing!</p>
          <button className={styles.shopNowBtn}>Shop Now</button>
        </div>
        <section className={styles.featuredProducts}>
          <h2>Featured Products</h2>
          <div className={styles.productList}>
            {/* Add product cards here */}
          </div>
        </section>
      </div>
    </>
  );
};

export default HomePage;
